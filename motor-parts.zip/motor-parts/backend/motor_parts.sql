-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 16, 2024 at 02:39 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `motor_parts`
--

-- --------------------------------------------------------

--
-- Table structure for table `inventories`
--

CREATE TABLE `inventories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `attributes` text DEFAULT NULL,
  `inventory` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventories`
--

INSERT INTO `inventories` (`id`, `name`, `price`, `attributes`, `inventory`) VALUES
(1, 'side mirror', 500.00, 'long', 990),
(2, 'sili', 20.00, 'vegetables', 980),
(3, 'gabi', 100.00, 'vegetables', 970),
(4, 'kamote', 200.00, 'vegetables', 1000),
(5, 'wheel', 1000.00, 'circle', 1000),
(6, 'rug', 5.00, 'circle', 1000);

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `item_id` int(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `quantity` int(20) NOT NULL,
  `price` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `name`, `quantity`, `price`) VALUES
(1, 'side mirror', 1, 500),
(2, 'sili', 1, 20),
(3, 'gabi', 1, 100),
(4, 'kamote', 1, 200),
(5, 'wheel', 1, 1000),
(6, 'rug', 1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `pos_data`
--

CREATE TABLE `pos_data` (
  `item_id` int(20) NOT NULL,
  `pos_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pos_data`
--

INSERT INTO `pos_data` (`item_id`, `pos_id`, `quantity`, `created_at`) VALUES
(1, 1, 10, '2024-12-16'),
(2, 2, 20, '2024-12-16'),
(3, 3, 30, '2024-12-16');

-- --------------------------------------------------------

--
-- Table structure for table `sales_data`
--

CREATE TABLE `sales_data` (
  `id` int(11) NOT NULL,
  `transaction_no` varchar(6) DEFAULT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `sales_date` datetime DEFAULT current_timestamp(),
  `item_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `sales_price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales_data`
--

INSERT INTO `sales_data` (`id`, `transaction_no`, `total_amount`, `sales_date`, `item_id`, `item_name`, `quantity`, `sales_price`, `total_price`) VALUES
(1, NULL, 8400.00, '2024-12-16 09:26:34', 0, '', 0, 0.00, 0.00),
(2, '1', 8400.00, '2024-12-16 09:26:34', 1, 'side mirror', 10, 500.00, 5000.00),
(3, '1', 8400.00, '2024-12-16 09:26:34', 2, 'sili', 20, 20.00, 400.00),
(4, '1', 8400.00, '2024-12-16 09:26:34', 3, 'gabi', 30, 100.00, 3000.00);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `first_name` varchar(20) NOT NULL,
  `user_id` int(15) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`first_name`, `user_id`, `last_name`, `username`, `password`, `last_login`) VALUES
('Jei Ann', 9, 'Aguinaldo', 'ann', 'kaonta', '2024-08-16 11:19:58'),
('caroot', 10, 'orange', 'lami', 'tamis', '2024-08-16 05:20:40'),
('atine', 11, 'pahong', 'root', 'justine123', '2024-08-24 00:36:52'),
('joem', 12, 'bato', 'saging', 'lami', '2024-08-18 05:11:47'),
('jessica', 13, 'aw', 'meow', '123', '2024-08-18 06:26:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `inventories`
--
ALTER TABLE `inventories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `pos_data`
--
ALTER TABLE `pos_data`
  ADD PRIMARY KEY (`pos_id`);

--
-- Indexes for table `sales_data`
--
ALTER TABLE `sales_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `inventories`
--
ALTER TABLE `inventories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `item_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `pos_data`
--
ALTER TABLE `pos_data`
  MODIFY `pos_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sales_data`
--
ALTER TABLE `sales_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
